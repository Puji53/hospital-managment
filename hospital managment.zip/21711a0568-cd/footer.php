<!DOCTYPE html>
<html>
<body>
    <footer>
        <p>&copy; 2024 Healthcare Management System. All rights reserved.</p>
    </footer>
</body>
</html>
